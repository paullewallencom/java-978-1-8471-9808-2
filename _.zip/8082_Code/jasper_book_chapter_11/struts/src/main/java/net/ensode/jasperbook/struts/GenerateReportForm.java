package net.ensode.jasperbook.struts;

import org.apache.struts.action.ActionForm;

public class GenerateReportForm extends ActionForm
{

}
