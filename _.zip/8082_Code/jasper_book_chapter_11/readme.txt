Please refer to the readme.txt in each subdirectory for instructions for each example.
