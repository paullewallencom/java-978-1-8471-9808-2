The file ant.properties needs to be modified to match your environment.



The "compile" ant target compiles the JRXML template and the source.



The "fillReport" ant target fills the report.



To view the generated report, type the following in the command line: "ant
-Drpt=HibernateQueryDemoReport view" (minus the double quotes).