package net.ensode.jasperbook.dbaccess.dao;

import net.ensode.jasperbook.dbaccess.base.BaseAircraftModelsDAO;

public class AircraftModelsDAO extends BaseAircraftModelsDAO
{

  /**
   * Default constructor. Can be used in place of getInstance()
   */
  public AircraftModelsDAO()
  {
  }

}