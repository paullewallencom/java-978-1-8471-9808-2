package net.ensode.jasperbook.dbaccess.dao;

import net.ensode.jasperbook.dbaccess.base.BaseAircraftTypesDAO;

public class AircraftTypesDAO extends BaseAircraftTypesDAO
{

  /**
   * Default constructor. Can be used in place of getInstance()
   */
  public AircraftTypesDAO()
  {
  }

}