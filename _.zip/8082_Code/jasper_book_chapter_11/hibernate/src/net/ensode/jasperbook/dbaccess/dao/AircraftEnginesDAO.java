package net.ensode.jasperbook.dbaccess.dao;

import net.ensode.jasperbook.dbaccess.base.BaseAircraftEnginesDAO;

public class AircraftEnginesDAO extends BaseAircraftEnginesDAO
{

  /**
   * Default constructor. Can be used in place of getInstance()
   */
  public AircraftEnginesDAO()
  {
  }

}