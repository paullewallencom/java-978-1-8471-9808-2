package net.ensode.jasperbook.dbaccess.dao;

import net.ensode.jasperbook.dbaccess.base.BaseAircraftDAO;

public class AircraftDAO extends BaseAircraftDAO
{

  /**
   * Default constructor. Can be used in place of getInstance()
   */
  public AircraftDAO()
  {
  }

}