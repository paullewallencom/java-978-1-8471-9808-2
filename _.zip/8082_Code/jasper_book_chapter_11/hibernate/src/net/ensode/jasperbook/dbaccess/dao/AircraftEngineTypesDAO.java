package net.ensode.jasperbook.dbaccess.dao;

import net.ensode.jasperbook.dbaccess.base.BaseAircraftEngineTypesDAO;

public class AircraftEngineTypesDAO extends BaseAircraftEngineTypesDAO
{

  /**
   * Default constructor. Can be used in place of getInstance()
   */
  public AircraftEngineTypesDAO()
  {
  }

}